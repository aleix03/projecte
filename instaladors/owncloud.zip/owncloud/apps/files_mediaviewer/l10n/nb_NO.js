OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Lukk",
    "Download" : "Last ned",
    "Fullscreen" : "Fullskjerm",
    "Loading" : "Laster",
    "Mute" : "Demp",
    "Next" : "Neste",
    "of" : "av",
    "Play" : "Spill",
    "Previous" : "Forrige",
    "Replay" : "Spill på nytt",
    "Rotate 90° counterclockwise" : "Roter 90° mot klokka",
    "Zoom in" : "Zoom inn",
    "Zoom out" : "Zoom ut"
},
"nplurals=2; plural=(n != 1);");
