OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Schließen",
    "Download" : "Herunterladen",
    "Fullscreen" : "Vollbildschirm",
    "Loading" : "Laden",
    "Mute" : "Ton aus",
    "Next" : "Nächstes",
    "of" : "von",
    "Play" : "Abspielen",
    "Previous" : "Vorheriges",
    "Replay" : "Wiederholen",
    "Rotate 90° counterclockwise" : "90° gegen den Uhrzeigersinn drehen",
    "Zoom in" : "Vergrößern",
    "Zoom out" : "Verkleinern",
    "files_mediaviewer" : "files_mediaviewer"
},
"nplurals=2; plural=(n != 1);");
