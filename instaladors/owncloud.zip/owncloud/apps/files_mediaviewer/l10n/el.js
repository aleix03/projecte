OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Κλείσιμο",
    "Download" : "Λήψη",
    "Fullscreen" : "Πλήρης οθόνη",
    "Loading" : "Γίνεται φόρτωση",
    "Next" : "Επόμενο",
    "Play" : "Αναπαραγωγή",
    "Previous" : "Προηγούμενο",
    "Replay" : "Επανάληψη",
    "Zoom in" : "Μεγέθυνση",
    "Zoom out" : "Σμίκρυνση"
},
"nplurals=2; plural=(n != 1);");
