OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Loka",
    "Download" : "Sækja",
    "Fullscreen" : "Fullskjár",
    "Loading" : "Hleð",
    "Mute" : "Þagga",
    "Next" : "Næsta",
    "of" : "af",
    "Play" : "Spila",
    "Previous" : "Fyrri",
    "Replay" : "Endurspila",
    "Rotate 90° counterclockwise" : "Snua 90° andsælis",
    "Zoom in" : "Þysja inn",
    "Zoom out" : "Þysja út",
    "files_mediaviewer" : "skrar_efnisveita"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
