OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "بند",
    "Download" : "ڈون لوڈ",
    "Fullscreen" : "فل سکرین ",
    "Loading" : "لوڈنگ ",
    "Mute" : "آواز بند ",
    "Next" : "آگے",
    "of" : "آف",
    "Play" : "پلے",
    "Previous" : "پیچھے",
    "Replay" : "دوبارہ پلے",
    "Rotate 90° counterclockwise" : "90°  گھماوگھڑی کی سمت ",
    "Zoom in" : "زوم ان",
    "Zoom out" : "زوم آوٹ ",
    "files_mediaviewer" : "فائلز _میڈیا وئیور"
},
"nplurals=2; plural=(n != 1);");
