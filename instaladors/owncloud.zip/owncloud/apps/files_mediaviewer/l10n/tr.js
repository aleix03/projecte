OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Kapat",
    "Download" : "İndir",
    "Fullscreen" : "Tam Ekran",
    "Loading" : "Yükleniyor",
    "Mute" : "Sessiz",
    "Next" : "Sonraki",
    "Play" : "Oynat",
    "Previous" : "Önceki",
    "Replay" : "Yeniden Oynat",
    "Rotate 90° counterclockwise" : "90° saat yönünün tersine döndür",
    "Zoom in" : "Yakınlaştır",
    "Zoom out" : "uzaklaştır"
},
"nplurals=2; plural=(n > 1);");
