OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "閉じる",
    "Download" : "ダウンロード",
    "Fullscreen" : "フルスクリーン",
    "Loading" : "読込中",
    "Mute" : "ミュート",
    "Next" : "次",
    "of" : "of",
    "Play" : "再生",
    "Previous" : "前",
    "Replay" : "リプレイ",
    "Rotate 90° counterclockwise" : "90°左回り",
    "Zoom in" : "ズームイン",
    "Zoom out" : "ズームアウト"
},
"nplurals=1; plural=0;");
