OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Cerrar",
    "Download" : "Descargar",
    "Fullscreen" : "Pantalla completa",
    "Loading" : "Cargando",
    "Mute" : "Silenciar",
    "Next" : "Siguiente",
    "of" : "de",
    "Play" : "Reproducir",
    "Previous" : "Anterior",
    "Replay" : "Rehacer",
    "Rotate 90° counterclockwise" : "Rotar 90° en sentido antihorario",
    "Zoom in" : "Acercar",
    "Zoom out" : "Alejar",
    "files_mediaviewer" : "files_mediaviewer"
},
"nplurals=2; plural=(n != 1);");
