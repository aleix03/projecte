OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Mbylle",
    "Download" : "Shkarkoje",
    "Fullscreen" : "Sa krejt ekrani",
    "Loading" : "Po ngarkohet",
    "Mute" : "Heshtoje",
    "Next" : "Pasuesi",
    "of" : "nga",
    "Play" : "Luaje",
    "Previous" : "I mëparshmi",
    "Replay" : "Riluaje",
    "Rotate 90° counterclockwise" : "Rrotulloje 90° në kahun kundërorar",
    "Zoom in" : "Zmadhoje",
    "Zoom out" : "Zvogëloje",
    "files_mediaviewer" : "files_mediaviewer"
},
"nplurals=2; plural=(n != 1);");
