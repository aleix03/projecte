# market
:convenience_store: MarketPlace/AppStore integration

[![Build Status](https://drone.owncloud.com/api/badges/owncloud/market/status.svg?branch=master)](https://drone.owncloud.com/owncloud/market)

See the [Frontend development](https://github.com/owncloud/market/wiki/Frontend-development-(WIP)) document to get going.
