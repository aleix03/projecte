<?php
$TRANSLATIONS = array(
"Documentation" => "ஆவணமாக்கல்"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
