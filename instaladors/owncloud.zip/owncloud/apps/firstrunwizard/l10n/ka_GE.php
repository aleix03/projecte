<?php
$TRANSLATIONS = array(
"Your personal web services. All your files, contacts, calendar and more, in one place." => "თქვენი პერსონალური web სერვისები. ყველა თქვენი ფაილი, კონტაქტი, კალენდარი და სხვა ერთად.",
"Get the apps to sync your files" => "აპლიკაცია ფაილების სინქრონიზაციისთვის",
"Connect your Calendar" => "დაუკავშირდით თქვენ კალენდარს",
"Connect your Contacts" => "დაუკავშირდით თქვენ კონტაქტებს",
"Access files via WebDAV" => "დაუკავშირდით ფაილებს WebDAV–ით",
"Documentation" => "დოკუმენტაცია"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
